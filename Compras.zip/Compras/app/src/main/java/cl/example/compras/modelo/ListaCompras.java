package cl.example.compras.modelo;

import java.util.ArrayList;

import cl.example.compras.ListaProductosActivity;

public class ListaCompras {
    private static ListaCompras instancia=new ListaCompras();
    private ArrayList<Producto> listaCompras;


    private ListaCompras() {
        listaCompras=new ArrayList<>();
        agregarProducto(new Producto("pan", 1, "kilo"));

    }
    public static ListaCompras getInstancia()
    {
        return instancia;
    }

    public void agregarProducto(Producto producto)
    {
        listaCompras.add(producto);
    }

    public Producto getProducto(int id)
    {
        return listaCompras.get(id);
    }

    public ArrayList<Producto> getListaCompras()
    {
        return listaCompras;
    }

}


