package cl.example.compras;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NuevoProductoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_producto);
    }
}